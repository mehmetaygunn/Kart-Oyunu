package KartOyunux;

import javax.swing.JButton;

public class KartF extends JButton {

	int penalti;
	int karsi_karsiya;
	int serbest_vurus;

	
	
	public KartF(int a,int b,int c) {
	penalti=a;
	karsi_karsiya=b;
	serbest_vurus=c;

		}

	
	
	
	
	
	
}
