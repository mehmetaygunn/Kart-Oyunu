package KartOyunux;


public class Kullanici extends Oyuncu{

	public Kullanici() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Kullanici(int oyuncuID, String oyuncuAdi, int skor) {
		super(oyuncuID, oyuncuAdi, skor);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
}
