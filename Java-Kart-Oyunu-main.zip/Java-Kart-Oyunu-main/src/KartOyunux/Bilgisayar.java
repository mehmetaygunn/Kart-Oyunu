package KartOyunux;


public class Bilgisayar extends Oyuncu {

	public Bilgisayar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bilgisayar(int oyuncuID, String oyuncuAdi, int skor) {
		super(oyuncuID, oyuncuAdi, skor);
		// TODO Auto-generated constructor stub
	}
		
	
	
	
	
}
