package KartOyunux;

import javax.swing.JButton;

public class KartB extends JButton {

	int ikilik;
	int ucluk;
	int serbest_atis;

	public KartB(int a,int b,int c) {
	
		ikilik=a;
		ucluk=b;
		serbest_atis=c;
	
		
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
