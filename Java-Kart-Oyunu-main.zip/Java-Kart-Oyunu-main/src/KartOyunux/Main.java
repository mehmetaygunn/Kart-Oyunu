package KartOyunux;

import javax.swing.JFrame;

public class Main{
	
	

	
	 public static void main(String[] args) {
		 OyunAlani oyunAlani = new OyunAlani();
		 Pencere pencere = new Pencere(oyunAlani);
		
		 //Statik Test objelerine eri�imimiz var.
	
		 
		 

		
		
		 
	 }	
}


