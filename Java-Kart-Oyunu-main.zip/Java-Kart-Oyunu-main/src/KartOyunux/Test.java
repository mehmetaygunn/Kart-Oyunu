package KartOyunux;


public class Test {
	
	static Futbolcu messi = new Futbolcu("messi","barcelona",90,95,96);
	static Futbolcu ronaldo = new Futbolcu("ronaldo", "juventus",95,82,91);
	static Futbolcu aguero = new Futbolcu("aguero", "mancity",89,80,90);
	static Futbolcu lewandowski = new Futbolcu("lewandowski", "bayern",97,83,92);
	static Futbolcu neymar = new Futbolcu("neymar", "psg",91,94,93);
	static Futbolcu mbappe = new Futbolcu("mbappe", "psg",87,93,89);
	static Futbolcu perotti = new Futbolcu("perotti", "fenerbahce",88,85,86);
	static Futbolcu sosa = new Futbolcu("sosa", "fenerbahce",92,89,85);
	static Basketbolcu lebron = new Basketbolcu("lebron","lakers", 96, 87, 91);
	static Basketbolcu curry = new Basketbolcu("curry","gsw", 90, 100, 93);
	static Basketbolcu durant = new Basketbolcu("durant","brooklyn", 92, 88, 85);		
	static Basketbolcu harden = new Basketbolcu("harden","houston", 91, 95, 90);
	static Basketbolcu doncic = new Basketbolcu("doncic","dallas",89, 89, 89);		
	static Basketbolcu klay = new Basketbolcu("klay","gsw", 88, 94, 88);
	static Basketbolcu davis = new Basketbolcu("davis","lakers", 87, 86, 87);
	static Basketbolcu kobe = new Basketbolcu("kobe","lakers", 95, 90, 95);
	
	
	
	
	
	
	

}
